create function
FUNC_ADD_TOPIC(topic_name in VARCHAR2, message_id in INTEGER)
return INTEGER
is 
PRAGMA AUTONOMOUS_TRANSACTION;
state INTEGER:=1;
temp_topic_id INTEGER:=-1;
topic_exist INTEGER:=0;
own_exist INTEGER:=0;

begin
select count(*) into topic_exist from Topic where topic_content = topic_name;
if topic_exist !=0 then
select topic_id into temp_topic_id from Topic where topic_content=topic_name;
update Topic set topic_heat = topic_heat + 1 where topic_id=temp_topic_id;
commit;
end if;

if topic_exist=0 then
insert into Topic(topic_heat, topic_content) 
values ( 1, topic_name);
select topic_id into temp_topic_id from Topic where topic_content=topic_name;
commit;
end if;

select count(*) into own_exist from Message_Owns_Topic 
where Message_Owns_Topic.message_id = message_id and Message_Owns_Topic.topic_id = temp_topic_id;

if own_exist=0 then
insert into Message_Owns_Topic(message_id, topic_id)values(message_id, temp_topic_id); 
end if;

commit;
return state;
end;
/

