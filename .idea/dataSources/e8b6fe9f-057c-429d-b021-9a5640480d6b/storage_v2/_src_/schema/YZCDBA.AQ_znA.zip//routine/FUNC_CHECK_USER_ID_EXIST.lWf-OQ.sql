create function 
FUNC_CHECK_USER_ID_EXIST(userid in VARCHAR)
return INTEGER
is 
state INTEGER;
begin 
select count(*)
into state
from USER_PUBLIC_INFO
where userid=USER_ID;
return state;
end;
/

