create trigger MESSAGE_ID_ADD
    before insert
    on MESSAGE
    for each row
begin
select SEQ_MESSAGE.NEXTVAL into :new.message_id from dual;
end Message_ID_ADD;
/

