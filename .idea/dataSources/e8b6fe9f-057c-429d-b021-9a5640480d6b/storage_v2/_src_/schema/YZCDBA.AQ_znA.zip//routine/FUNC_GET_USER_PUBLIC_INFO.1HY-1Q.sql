create function FUNC_GET_USER_PUBLIC_INFO(userid in INTEGER, info out sys_refcursor)
return INTEGER
is
state INTEGER:=1;
begin
state:=FUNC_CHECK_USER_ID_EXIST(userid);
if state=0 then
return state;
end if;

open info for 
select user_id,user_nickname,user_register_time,user_self_introduction,user_followers_num,user_follows_num
from USER_PUBLIC_INFO where user_id=userid;

return state;
end;
/

