create function 
FUNC_SHOW_MESSAGE_BY_RANGE(user_id in INTEGER, rangeStart in INTEGER, rangeLimitation in INTEGER, search_result out sys_refcursor)
return INTEGER
is 
state INTEGER:=0;

begin

select count(*) into state
from MESSAGE 
where MESSAGE_SENDER_USER_ID = user_id;

if state!=0 then
  open search_result for 
  select * from 
    (select * 
     from (message natural left join message_image) natural left join transpond
     where message_sender_user_id=user_id
     order by message_id desc)
  where rownum <rangeLimitation+rangeStart
  minus
  select * from 
    (select * 
     from (message natural left join message_image) natural left join transpond
     where message_sender_user_id=user_id
     order by message_id desc)
  where rownum <rangeStart;

end if;
return state;
end;
/

