create function func_get_user_id_by_name
(Searchkey In Varchar2, Search_Result Out Integer)
return INTEGER
is
state integer:=0;

begin
	select count(*) into state 
  from user_public_info
  where USER_NICKNAME = Searchkey;

if state!=0 then 
state:=1;
  select user_id into Search_Result
  from user_public_info
  where USER_NICKNAME = Searchkey;
end if;

return state;
end;
/

