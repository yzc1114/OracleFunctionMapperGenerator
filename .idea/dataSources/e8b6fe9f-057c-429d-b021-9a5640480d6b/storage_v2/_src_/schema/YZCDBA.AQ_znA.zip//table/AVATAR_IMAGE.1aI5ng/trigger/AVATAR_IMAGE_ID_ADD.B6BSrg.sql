create trigger AVATAR_IMAGE_ID_ADD
    before insert
    on AVATAR_IMAGE
    for each row
begin
select SEQ_AVATAR_IMAGE.NEXTVAL into :new.avatar_image_id from dual;
end Avatar_Image_ID_ADD;
/

