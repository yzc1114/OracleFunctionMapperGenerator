create FUNCTION FUNC_QUERY_TOPICS_BY_HEAT
(startFrom IN INTEGER, limitation IN INTEGER, search_result OUT sys_refcursor)
RETURN INTEGER
AS
state INTEGER:=1;

BEGIN

	SELECT count(*) into state 
  from TOPIC;

  IF state=0
  THEN 
    return state;
  ELSE  
    open search_result for 
    SELECT* FROM 
         (SELECT *
          FROM TOPIC
         ORDER BY TOPIC.TOPIC_HEAT DESC)
    WHERE ROWNUM<=startFrom+limitation
    MINUS
    SELECT* FROM 
         (SELECT *
          FROM TOPIC
         ORDER BY TOPIC.TOPIC_HEAT DESC)
    WHERE ROWNUM<=startFrom-1;

    state:=1;
  END IF;
	RETURN state;
END;
/

