create function 
FUNC_DELETE_MESSAGE(message_id_input in INTEGER, message_has_image_iftrue out INTEGER)
return INTEGER
is 
PRAGMA AUTONOMOUS_TRANSACTION;
state integer:=0;
temp_id integer:=message_id_input;

begin
select count(*) into state 
from MESSAGE 
where message_id = temp_id;

if state != 0 then 
state:=1;
else
select message_has_image into message_has_image_iftrue
from  message
where message_id = temp_id;
delete from MESSAGE 
where message_id = temp_id;
delete from COMMENT_ON_MESSAGE 
where  COMMENT_MESSAGE_ID=temp_id ;
end if;
end;
/

