create trigger COMMENT_ON_MESSAGE_ID_ADD
    before insert
    on COMMENT_ON_MESSAGE
    for each row
begin
select SEQ_COMMENT_ON_MESSAGE.NEXTVAL into :new.comment_id from dual;
end Comment_On_Message_ID_ADD;
/

