create function FUNC_GET_MESSAGE_NUMS
(m_user_id In INTEGER, search_result OUT Sys_refcursor)
return INTEGER
is
state integer:=1;

begin
open search_result for
	select count(*) as message_num from USER_PUBLIC_INFO, MESSAGE 
  where m_user_id = Message.message_sender_user_id and USER_PUBLIC_INFO.user_id = m_user_id;


return state;
end;
/

