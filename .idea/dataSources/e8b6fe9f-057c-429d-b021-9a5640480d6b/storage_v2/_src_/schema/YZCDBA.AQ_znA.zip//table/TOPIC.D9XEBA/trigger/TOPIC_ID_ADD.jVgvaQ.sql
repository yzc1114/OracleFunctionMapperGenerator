create trigger TOPIC_ID_ADD
    before insert
    on TOPIC
    for each row
begin
select SEQ_TOPIC.NEXTVAL into :new.topic_id from dual;
end Topic_ID_ADD;
/

