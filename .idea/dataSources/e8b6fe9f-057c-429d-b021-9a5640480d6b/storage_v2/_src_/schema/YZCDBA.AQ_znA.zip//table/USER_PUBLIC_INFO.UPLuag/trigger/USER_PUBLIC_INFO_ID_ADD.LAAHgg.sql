create trigger USER_PUBLIC_INFO_ID_ADD
    before insert
    on USER_PUBLIC_INFO
    for each row
begin
select SEQ_USER_PUBLIC_INFO.NEXTVAL into :new.user_id from dual;
end User_Public_Info_ID_ADD;
/

