create function
FUNC_QUERY_COMMENT_BY_RANGE(message_id in INTEGER, startFrom IN INTEGER, limitation IN INTEGER, search_result OUT Sys_refcursor)
return INTEGER
AS
state INTEGER:= 1;
begin

select count(*) into state
from Message tb where tb.message_id = message_id;

open search_result for
SELECT* FROM 
        (SELECT *
          FROM comment_on_message
          WHERE comment_message_id = message_id
          ORDER BY comment_id DESC)
          WHERE ROWNUM <= startFrom+limitation
        MINUS
SELECT * FROM 
         (SELECT *
          FROM comment_on_message
          WHERE comment_message_id = message_id
         ORDER BY comment_id DESC)
    WHERE ROWNUM<=startFrom-1;

commit;
return state;
end;
/

