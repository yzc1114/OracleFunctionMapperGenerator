create function 
FUNC_QUERY_COLLECTIONS_OF_MINE(user_id in INTEGER, startFrom in INTEGER, limitation in INTEGER, search_result out sys_refcursor)
return INTEGER
is 
state INTEGER:=0;

begin
select count(*) into state
from MESSAGE_COLLECTION
where MESSAGE_COLLECTION.USER_ID = user_id;

if state=0 then 
return state;
else
state:=1;
open search_result for 
select * from(
select MESSAGE_COLLECTION.MESSAGE_ID
from MESSAGE_COLLECTION
where MESSAGE_COLLECTION.USER_ID= user_id)
where ROWNUM >= startFrom and ROWNUM <= limitation;

end if;
return state;
end;
/

