create function 
FUNC_QUERY_FOLLOWERS_LIST(my_user_id in INTEGER, startFrom in INTEGER, limitation in INTEGER, search_result out sys_refcursor)
return INTEGER
is 
id_temp NUMBER(38,0);
state INTEGER:=0;
create_time VARCHAR2(30);
begin


select count(*) into state
from RELATION 
where relation_user_be_followed_id = my_user_id;

if state!=0 then 
state:=1;
end if;
open search_result for
select* from(
select user_id, user_nickname, RELATION_CREATE_TIME
from USER_PUBLIC_INFO,RELATION 
where my_user_id=RELATION.RELATION_USER_BE_FOLLOWED_ID and
user_id=RELATION.RELATION_USER_FOLLOWER_ID
order by RELATION_CREATE_TIME desc)
where ROWNUM <startFrom+limitation
minus
select* from(
select user_id, user_nickname, RELATION_CREATE_TIME
from USER_PUBLIC_INFO,RELATION 
where my_user_id=RELATION.RELATION_USER_BE_FOLLOWED_ID and
user_id=RELATION.RELATION_USER_FOLLOWER_ID
order by RELATION_CREATE_TIME desc)
where ROWNUM <startFrom;


return state;
end;
/

