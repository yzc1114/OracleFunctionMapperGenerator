create FUNCTION FUNC_QUERY_IF_USER_COLLECTS
(user_id IN INTEGER, message_id IN INTEGER)
RETURN INTEGER
AS
state INTEGER:=1;
q_user_id INTEGER:= user_id;
q_message_id INTEGER:= message_id;

BEGIN
select count(*) into state
from MESSAGE_COLLECTION tb where tb.user_id = q_user_id and tb.message_id = q_message_id;

RETURN state;

END;
/

