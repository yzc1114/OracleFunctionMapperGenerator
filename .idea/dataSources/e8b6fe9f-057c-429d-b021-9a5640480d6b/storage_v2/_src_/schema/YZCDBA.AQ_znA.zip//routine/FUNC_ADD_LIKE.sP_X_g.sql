create FUNCTION FUNC_ADD_LIKE 
(user_id IN INTEGER, like_message_id IN INTEGER)
RETURN INTEGER
AS
temp_date VARCHAR2(30);
temp_topic_state INTEGER:=0;
state INTEGER:=1;
BEGIN

  SELECT count(*) into state 
  FROM MESSAGE
  WHERE MESSAGE.MESSAGE_ID=like_message_id;

  if state=0
  THEN
    return state;
  END IF;

  SELECT count(*) into temp_topic_state 
  FROM MESSAGE_OWNS_TOPIC
  WHERE MESSAGE_OWNS_TOPIC.MESSAGE_ID=like_message_id;

  if temp_topic_state>0
  THEN
    UPDATE TOPIC temp_topic
    SET TOPIC_HEAT=TOPIC_HEAT+1
    WHERE TEMP_TOPIC.TOPIC_ID IN (SELECT TOPIC_ID
                                  FROM MESSAGE_OWNS_TOPIC
                                  WHERE MESSAGE_OWNS_TOPIC.MESSAGE_ID=like_message_id);
  END IF;



  UPDATE MESSAGE
  set MESSAGE_AGREE_NUM=MESSAGE_AGREE_NUM+1,MESSAGE_HEAT=MESSAGE_HEAT+1
  WHERE MESSAGE.MESSAGE_ID=like_message_id;




  SELECT to_char(sysdate,'yyyy-mm-dd HH24:MI:SS')into temp_date from dual ;

  insert into LIKES
      (LIKES_USER_ID, LIKES_MESSAGE_ID,LIKES_TIME)
  values(user_id, like_message_id, temp_date);
  state:=1;

	RETURN state;
END;

/

