create function ADD_AVATAR(user_id in INTEGER, avatar_id out INTEGER)
return INTEGER
is
PRAGMA AUTONOMOUS_TRANSACTION;
state INTEGER:=1;
m_user_id INTEGER:=user_id;
begin

insert into AVATAR_IMAGE(USER_ID, AVATAR_IMAGE_IN_USE) VALUES (m_user_id, 0) returning AVATAR_IMAGE_ID into avatar_id;
commit;
return state;
end;
/

