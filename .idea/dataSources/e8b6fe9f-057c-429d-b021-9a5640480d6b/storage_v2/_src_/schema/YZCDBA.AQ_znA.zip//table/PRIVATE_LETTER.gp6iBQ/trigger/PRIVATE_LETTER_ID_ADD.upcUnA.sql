create trigger PRIVATE_LETTER_ID_ADD
    before insert
    on PRIVATE_LETTER
    for each row
begin
select SEQ_PRIVATE_LETTER.NEXTVAL into :new.private_letter_id from dual;
end Private_Letter_ID_ADD;
/

