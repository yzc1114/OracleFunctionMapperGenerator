create function 
FUNC_SHOW_MESSAGE_BY_ID(message_id_input in INTEGER, result out sys_refcursor)
return INTEGER
is
state INTEGER:=0;
begin
select count(*) into state 
from message
where message_id=message_id_input;
if state != 0 then
open result for
select *
from message natural left join message_image natural left join transpond
where message_id =message_id_input;
end if;


return state;
end;
/

