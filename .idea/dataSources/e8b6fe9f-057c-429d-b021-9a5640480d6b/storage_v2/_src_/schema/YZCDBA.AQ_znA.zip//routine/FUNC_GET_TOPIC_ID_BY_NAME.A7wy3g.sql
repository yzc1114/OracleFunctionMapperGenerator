create function func_get_topic_id_by_name
(Searchkey In Varchar2, Search_Result Out Integer)
return INTEGER
is
state integer:=0;

begin
	select count(*) into state 
  from topic
  where topic_content = Searchkey;

if state!=0 then 
state:=1;
  select topic_id into Search_Result
  from TOPIC
  where TOPIC_CONTENT = Searchkey;
end if;

return state;
end;
/

