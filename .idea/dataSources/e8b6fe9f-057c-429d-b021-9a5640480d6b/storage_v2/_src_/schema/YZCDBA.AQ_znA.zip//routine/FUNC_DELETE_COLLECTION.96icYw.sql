create function 
FUNC_DELETE_COLLECTION(user_id_input in INTEGER, message_id_input in INTEGER)
return INTEGER
is 
PRAGMA AUTONOMOUS_TRANSACTION;
state INTEGER:=0;

begin
select count(*) into state 
from message 
where message_id = message_id_input;

if state != 0 then 
state:=1;

delete from message_collection
where message_id = message_id_input and user_id=user_id_input;

update MESSAGE 
set message_heat=message_heat-1
where message_id =message_id_input;

update TOPIC 
set TOPIC_HEAT=TOPIC_HEAT-1
where topic_id in ( select TOPIC_ID 
from message_owns_topic
where message_id = message_id_input);
end if;

commit;
return state;
end;
/

